#!/bin/bash

echo "—————————————————————————Instalando programas em snap———————————————————————————"

sudo snap install authy spotify discord lunacy;

echo "—————————————————————————Programas em snap instalados———————————————————————————"


