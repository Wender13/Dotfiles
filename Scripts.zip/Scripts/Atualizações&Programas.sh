#!/bin/bash

echo "—————————————————————————————Atualizando o sistema——————————————————————————————"

sudo dnf upgrade -y

echo "———————————————————————————————Sistema atualizado———————————————————————————————"

echo "—————————————————————————————Instalando programas———————————————————————————————"

sudo dnf install nodejs gnome-tweaks zsh fzf powerline-fonts snapd fira-code-fonts ifuse make wget gimp neofetch bpytop steam ulauncher rustc gnome-shell-extension-pop-shell xprop install java-11-openjdk  -y;
cargo install ttyper;
cd ~/.cargo/bin;
sudo cp ttyper /bin/;
cd ~;
wget "https://github.com/AppImage/appimaged/releases/download/continuous/appimaged-x86_64.AppImage";
chmod +x "appimaged*.AppImage";
sudo chmod +x appimaged-x86_64.AppImage;
./appimaged-x86_64.AppImage --install;
cd ~/Downloads;
wget https://packages.microsoft.com/yumrepos/edge/microsoft-edge-stable-106.0.1370.42-1.x86_64.rpm;
flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo;
flatpak install flathub io.github.prateekmedia.appimagepool;
flatpak install flathub org.kde.ktouch;
sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc;
sudo sh -c 'echo -e "[code]\nname=Visual Studio Code\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\nenabled=1\ngpgcheck=1\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc" > /etc/yum.repos.d/vscode.repo';
sudo dnf check-update;
sudo dnf install code;

echo "—————————————————————————————Programas instalados———————————————————————————————"

echo "——————————————————————————Instalando temas e ícones—————————————————————————————"

cd ~/Downloads;

git clone https://github.com/yeyushengfan258/Reversal-icon-theme.git;
git clone https://github.com/vinceliuice/Vimix-cursors.git;
git clone https://github.com/daniruiz/skeuos-gtk.git;

echo "——————————————————————————Temas e ícones instalados—————————————————————————————"

